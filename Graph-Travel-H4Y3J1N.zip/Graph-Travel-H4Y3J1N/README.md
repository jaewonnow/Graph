# Graph Travel - for beginner

A weekly GNN model tutorial is uploaded here.

with GUG, Let's explore the Graph Neural Network!

[✈🎫 Want to know about GUG?](https://www.graphusergroup.com/)
